/*
 * @file   NewgameActivity.java
 * @author Alexandre Duquesne and Alexandre Manchon
 * @date   31/01/2015
 * @brief  This is an android application/game named ADAM develloped for Universit� du Havre project
 * All rights reserved
 */


package com.example.adam;

/**
 * Les import
 */
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.TextView;

/**
 * La classe principal du jeu
 */
public class NewgameActivity extends Activity {
	
	/**
	 * Les champs
	 */
	
	// Le x correspond aux coordonn�es horizontales du personnage
	private int x;
	
	// Le bouton pour aller � droite
	private Button bouton_droit;
	// Le bouton pour aller � gauche
	private Button bouton_gauche;
	
	// Une vue pour chaque image du personnage
	private View personnage_gauche;
	private View personnage_droit;
	private View personnage_gauche_1;
	private View personnage_gauche_2;
	private View personnage_gauche_3;
	private View personnage_gauche_4;
	private View personnage_gauche_5;
	private View personnage_gauche_6;
	private View personnage_droite_1;
	private View personnage_droite_2;
	private View personnage_droite_3;
	private View personnage_droite_4;
	private View personnage_droite_5;
	private View personnage_droite_6;
	
	// Les missiles
	private View missile1;
	private View missile2;
	private View missile3;
	private View missile4;
	private View missile5;
	private View missile6;
	private View missile7;
	private View missile8;
	private View missile9;
	private View missile10;
	private View missile11;
	private View missile12;
	private View missile13;
	private View missile14;
	private View missile15;
	private View missile16;
	private View missile17;
	private View missile18;
	private View missile19;
	private View missile20;
	
	// fin du jeu ou non
	private boolean gameover=false;
	
	// Le nombre de missiles lances
	private int missiles_lances = 0;
	
	// L'ordonnee de chaque missile
	private int missile1_y, missile2_y, missile3_y, missile4_y, missile5_y, missile6_y, missile7_y, missile8_y, missile9_y, missile10_y, missile11_y, missile12_y, missile13_y, missile14_y, missile15_y, missile16_y, missile17_y, missile18_y, missile19_y, missile20_y;
	
	// Missile_x lance ou non
	private boolean missile1_lance = false, missile2_lance = false, missile3_lance = false, missile4_lance = false, missile5_lance = false, missile6_lance = false, missile7_lance = false, missile8_lance = false, missile9_lance = false, missile10_lance = false, missile11_lance = false, missile12_lance = false, missile13_lance = false, missile14_lance = false, missile15_lance = false, missile16_lance = false, missile17_lance = false, missile18_lance = false, missile19_lance = false, missile20_lance = false;
	
	private AsyncTask<Void, Void, Void> asyncMissile = null;
	
	// La taille de la largeur de l'ecran /2
	private int moitie_largeur;
	
	// Si le bouton est appuye ou non
	private boolean droiteDown;
	private boolean gaucheDown;
	
	// Pour le deplacement du personnage
	private AsyncTask<Void, Void, Void> asyncCourseDroite = null;
	private AsyncTask<Void, Void, Void> asyncCourseGauche = null;
	
	// Necessaire pour l'affichage et l'evolution du score
	private TextView score;
	private int scores=0;
	private int multiplicateur_score=1;
	private int variable500=0;
	
	// Vitesse des missiles
	private int vitesse_deplacement=20;
	
	// Affichage du meilleur score
	private TextView highscore_view;
	
	// Sauvegarde du meilleur score
	public static String SCORE_SAVED = "savedScore";
	
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_newgame);
		
		// Fais correspondre les vues et les boutons aux ImageView et Button d'activity_newgame.xml
		bouton_droit = (Button)findViewById(R.id.bouton_droit_id);
		bouton_gauche = (Button)findViewById(R.id.bouton_gauche_id);
		
		personnage_gauche=findViewById(R.id.perso_gauche_0);
		personnage_droit=findViewById(R.id.perso_droite_0);
		
		personnage_gauche_1=findViewById(R.id.perso_gauche_1);
		personnage_gauche_2=findViewById(R.id.perso_gauche_2);
		personnage_gauche_3=findViewById(R.id.perso_gauche_3);
		personnage_gauche_4=findViewById(R.id.perso_gauche_4);
		personnage_gauche_5=findViewById(R.id.perso_gauche_5);
		personnage_gauche_6=findViewById(R.id.perso_gauche_6);
		personnage_droite_1=findViewById(R.id.perso_droite_1);
		personnage_droite_2=findViewById(R.id.perso_droite_2);
		personnage_droite_3=findViewById(R.id.perso_droite_3);
		personnage_droite_4=findViewById(R.id.perso_droite_4);
		personnage_droite_5=findViewById(R.id.perso_droite_5);
		personnage_droite_6=findViewById(R.id.perso_droite_6);
		
		missile1=findViewById(R.id.missile_01);
		missile2=findViewById(R.id.missile_02);
		missile3=findViewById(R.id.missile_03);
		missile4=findViewById(R.id.missile_04);
		missile5=findViewById(R.id.missile_05);
		missile6=findViewById(R.id.missile_06);
		missile7=findViewById(R.id.missile_07);
		missile8=findViewById(R.id.missile_08);
		missile9=findViewById(R.id.missile_09);
		missile10=findViewById(R.id.missile_10);
		missile11=findViewById(R.id.missile_11);
		missile12=findViewById(R.id.missile_12);
		missile13=findViewById(R.id.missile_13);
		missile14=findViewById(R.id.missile_14);
		missile15=findViewById(R.id.missile_15);
		missile16=findViewById(R.id.missile_16);
		missile17=findViewById(R.id.missile_17);
		missile18=findViewById(R.id.missile_18);
		missile19=findViewById(R.id.missile_19);
		missile20=findViewById(R.id.missile_20);
		
		score = (TextView)findViewById(R.id.score);
		highscore_view = (TextView)findViewById(R.id.highscore);
		
		// Pour afficher le score
		score.setText(ScoreToString(scores));
		
		// moitie de la largeur de l'ecran
		moitie_largeur=getWidth()/2;
		
		// Mise en place des preferences pour garder le meilleur score en memoire
		SharedPreferences prefs = this.getSharedPreferences(SCORE_SAVED, Context.MODE_PRIVATE);
		int highscore = prefs.getInt("saved",prefs.getInt("highScore", 0));
		highscore_view.setText(ScoreToString(highscore));
		
		// Mise en place des missiles
		attaque();
		
		// Un premier thread gerant le lancement des missiles "chacun leur tour"
		new Thread(new Runnable() 
		  {
		         public void run() 
		         {
		        	 while(missiles_lances <20)
		        	 {
		        		 lancementMissile();
		        	 }
		         }
		     }).start();

		// Deuxieme thread s'executant tant que la partie n'est pas perdu
		// gerant le deplacement des missiles, leur vitesse et le score (proportionnel � la vitesse des missiles)
		
		new Thread(new Runnable() 
		  {
		         public void run() 
		         {
		        	 while(!gameover){
		        	 try 
	                 {
		        		 Thread.sleep(vitesse_deplacement);
		        		 variable500++;
		        		 if(variable500>500)
		        		 {
		        			 variable500=0;
		        			 multiplicateur_score++;
		        			 vitesse_deplacement-=1;
		        		 }
		        		 
	                     runOnUiThread(new Runnable() 
	                     {
	                      public void run() 
	                         {
	                          try 
	                             {
	                        	  deplacementMissile();
	                             } 
	                             catch (InterruptedException e) 
	                             {
	                              e.printStackTrace();
	                             }
	                         }
	                     });
	                 } 
	                catch (InterruptedException e) 
	                 {
	                     e.printStackTrace();
	                 }
		        	 }
		         }
		     }).start();
		
		 // Bouton gerant le deplacement du personnage vers la droite et vers la gauche
		 bouton_droit.setOnTouchListener(new droiteListener());
		 bouton_gauche.setOnTouchListener(new gaucheListener());
		 
		 
	}
	
	// Methode renvoyant la hauteur de l'ecran
	public final int getHeight()
	 {
	  DisplayMetrics dm = new DisplayMetrics();
	  getWindowManager().getDefaultDisplay().getMetrics(dm);
	  final int height = dm.heightPixels;
	  return height;
	 }
	
	// Methode renvoyant la largeur de l'ecran
	public final int getWidth()
	 {
	  DisplayMetrics dm = new DisplayMetrics();
	  getWindowManager().getDefaultDisplay().getMetrics(dm);
	  final int width = dm.widthPixels;
	  return width;
	 }
	
	// Methode mettant en place les missiles
	public void attaque()
	  {
	   missile1.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile1.setY(-getHeight()*96/100);
	   missile1_y = (int)missile1.getY();
	   missile2.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile2.setY(-getHeight()*96/100);
	   missile2_y = (int)missile2.getY();
	   missile3.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile3.setY(-getHeight()*96/100);
	   missile3_y = (int)missile3.getY();
	   missile4.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile4.setY(-getHeight()*96/100);
	   missile4_y = (int)missile4.getY();
	   missile5.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile5.setY(-getHeight()*96/100);
	   missile5_y = (int)missile5.getY();
	   missile6.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile6.setY(-getHeight()*96/100);
	   missile6_y = (int)missile6.getY();
	   missile7.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile7.setY(-getHeight()*96/100);
	   missile7_y = (int)missile7.getY();
	   missile8.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile8.setY(-getHeight()*96/100);
	   missile8_y = (int)missile8.getY();
	   missile9.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile9.setY(-getHeight()*96/100);
	   missile9_y = (int)missile9.getY();
	   missile10.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile10.setY(-getHeight()*96/100);
	   missile10_y = (int)missile10.getY();
	   missile11.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile11.setY(-getHeight()*96/100);
	   missile11_y = (int)missile11.getY();
	   missile12.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile12.setY(-getHeight()*96/100);
	   missile12_y = (int)missile12.getY();
	   missile13.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile13.setY(-getHeight()*96/100);
	   missile13_y = (int)missile13.getY();
	   missile14.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile14.setY(-getHeight()*96/100);
	   missile14_y = (int)missile14.getY();
	   missile15.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile15.setY(-getHeight()*96/100);
	   missile15_y = (int)missile15.getY();
	   missile16.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile16.setY(-getHeight()*96/100);
	   missile16_y = (int)missile16.getY();
	   missile17.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile17.setY(-getHeight()*96/100);
	   missile17_y = (int)missile17.getY();
	   missile18.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile18.setY(-getHeight()*96/100);
	   missile18_y = (int)missile18.getY();
	   missile19.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile19.setY(-getHeight()*96/100);
	   missile19_y = (int)missile19.getY();
	   missile20.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
	   missile20.setY(-getHeight()*96/100);
	   missile20_y = (int)missile20.getY();
	   
	   missile1.setVisibility(View.VISIBLE);
	   missile2.setVisibility(View.VISIBLE);
	   missile3.setVisibility(View.VISIBLE);
	   missile4.setVisibility(View.VISIBLE);
	   missile5.setVisibility(View.VISIBLE);
	   missile6.setVisibility(View.VISIBLE);
	   missile7.setVisibility(View.VISIBLE);
	   missile8.setVisibility(View.VISIBLE);
	   missile9.setVisibility(View.VISIBLE);
	   missile10.setVisibility(View.VISIBLE);
	   missile11.setVisibility(View.VISIBLE);
	   missile12.setVisibility(View.VISIBLE);
	   missile13.setVisibility(View.VISIBLE);
	   missile14.setVisibility(View.VISIBLE);
	   missile15.setVisibility(View.VISIBLE);
	   missile16.setVisibility(View.VISIBLE);
	   missile17.setVisibility(View.VISIBLE);
	   missile18.setVisibility(View.VISIBLE);
	   missile19.setVisibility(View.VISIBLE);
	   missile20.setVisibility(View.VISIBLE);
	   
	  }
	
	// Methode s'occupant du deplacement des missiles ainsi que l'eventuel collision avec le personnage
	// passant dans ce cas le booleen gameover a vrai
	// Lorsqu'un missile touche le sol, il est replace en haut de l'ecran pour retomber et ainsi de suite
	// Le score est incremente a chaque fois qu'un missile touche le sol
	public void deplacementMissile() throws InterruptedException
	 {
		if(missile1_lance){
			if(missile1.getX()<personnage_gauche.getX()+50 && missile1.getX()>personnage_gauche.getX()-50)
			{
				if(missile1.getY()>getHeight()-70 && missile1.getY()<getHeight())
					{
						gameover=true;
					}
			}
			if(missile1.getY()>getHeight()){
				missile1.setY(-getHeight()*96/100);
				 missile1_y = (int)missile1.getY();
				 missile1.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
		 missile1.setY(missile1_y+getHeight()*1/100);
		 missile1_y = (int)missile1.getY();
		 
		}
		if(missile2_lance){
			if(missile2.getX()<personnage_gauche.getX()+50 && missile2.getX()>personnage_gauche.getX()-50)
			{
				if(missile2.getY()>getHeight()-70 && missile2.getY()<getHeight())
				{
					gameover=true;
				}
			}
			if(missile2.getY()>getHeight()){
				 missile2.setY(-getHeight()*96/100);
				 missile2_y = (int)missile2.getY();
				 missile2.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile2.setY(missile2_y+getHeight()*1/100);
	     missile2_y = (int)missile2.getY();
		}
	     if(missile3_lance){
	    	 if(missile3.getX()<personnage_gauche.getX()+50 && missile3.getX()>personnage_gauche.getX()-50)
				{
					if(missile3.getY()>getHeight()-70 && missile3.getY()<getHeight())
					{
						gameover=true;
					}
				}
	    	 if(missile3.getY()>getHeight()){
				 missile3.setY(-getHeight()*96/100);
				 missile3_y = (int)missile3.getY();
				 missile3.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile3.setY(missile3_y+getHeight()*1/100);
	     missile3_y = (int)missile3.getY();
	     }
	     if(missile4_lance){
	    	 if(missile4.getX()<personnage_gauche.getX()+50 && missile4.getX()>personnage_gauche.getX()-50)
				{
					if(missile4.getY()>getHeight()-70 && missile4.getY()<getHeight())
					{
						gameover=true;
					}
				}
	    	 if(missile4.getY()>getHeight()){
				 missile4.setY(-getHeight()*96/100);
				 missile4_y = (int)missile4.getY();
				 missile4.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile4.setY(missile4_y+getHeight()*1/100);
	     missile4_y = (int)missile4.getY();
	     }
	     if(missile5_lance){
	    	 if(missile5.getX()<personnage_gauche.getX()+50 && missile5.getX()>personnage_gauche.getX()-50)
				{
					if(missile5.getY()>getHeight()-70 && missile5.getY()<getHeight())
					{
						gameover=true;
					}
				}
	    	 if(missile5.getY()>getHeight()){
				 missile5.setY(-getHeight()*96/100);
				 missile5_y = (int)missile5.getY();
				 missile5.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile5.setY(missile5_y+getHeight()*1/100);
	     missile5_y = (int)missile5.getY();
	     }
	     if(missile6_lance){
	    	 if(missile6.getX()<personnage_gauche.getX()+50 && missile6.getX()>personnage_gauche.getX()-50)
				{
					if(missile6.getY()>getHeight()-70 && missile6.getY()<getHeight())
					{
						gameover=true;
					}
				}
	    	 if(missile6.getY()>getHeight()){
				 missile6.setY(-getHeight()*96/100);
				 missile6_y = (int)missile6.getY();
				 missile6.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile6.setY(missile6_y+getHeight()*1/100);
	     missile6_y = (int)missile6.getY();
	     }
	     if(missile7_lance){
	    	 if(missile7.getX()<personnage_gauche.getX()+50 && missile7.getX()>personnage_gauche.getX()-50)
				{
					if(missile7.getY()>getHeight()-70 && missile7.getY()<getHeight())
					{
						gameover=true;
					}
				}
	    	 if(missile7.getY()>getHeight()){
				 missile7.setY(-getHeight()*96/100);
				 missile7_y = (int)missile7.getY();
				 missile7.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile7.setY(missile7_y+getHeight()*1/100);
	     missile7_y = (int)missile7.getY();
	     }
	     if(missile8_lance){
	    	 if(missile8.getX()<personnage_gauche.getX()+50 && missile8.getX()>personnage_gauche.getX()-50)
				{
					if(missile8.getY()>getHeight()-70 && missile8.getY()<getHeight())
					{
						gameover=true;
					}
				}
	    	 if(missile8.getY()>getHeight()){
				 missile8.setY(-getHeight()*96/100);
				 missile8_y = (int)missile8.getY();
				 missile8.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile8.setY(missile8_y+getHeight()*1/100);
	     missile8_y = (int)missile8.getY();
	     }
	     if(missile9_lance){
	    	 if(missile9.getX()<personnage_gauche.getX()+50 && missile9.getX()>personnage_gauche.getX()-50)
	 			{
	 				if(missile9.getY()>getHeight()-70 && missile9.getY()<getHeight())
	 				{
	 					gameover=true;
	 				}
	 			}
	    	 if(missile9.getY()>getHeight()){
				 missile9.setY(-getHeight()*96/100);
				 missile9_y = (int)missile9.getY();
				 missile9.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile9.setY(missile9_y+getHeight()*1/100);
	     missile9_y = (int)missile9.getY();
	     }
	     if(missile10_lance){
	    	 if(missile10.getX()<personnage_gauche.getX()+50 && missile10.getX()>personnage_gauche.getX()-50)
				{
					if(missile10.getY()>getHeight()-70 && missile10.getY()<getHeight())
					{
						gameover=true;
					}
				}
	    	 if(missile10.getY()>getHeight()){
				 missile10.setY(-getHeight()*96/100);
				 missile10_y = (int)missile10.getY();
				 missile10.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile10.setY(missile10_y+getHeight()*1/100); 
	     missile10_y = (int)missile10.getY();
	     }
	     if(missile11_lance){
	    	 if(missile11.getX()<personnage_gauche.getX()+50 && missile11.getX()>personnage_gauche.getX()-50)
				{
					if(missile11.getY()>getHeight()-70 && missile11.getY()<getHeight())
					{
						gameover=true;
					}
				}
	    	 if(missile11.getY()>getHeight()){
				 missile11.setY(-getHeight()*96/100);
				 missile11_y = (int)missile11.getY();
				 missile11.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile11.setY(missile11_y+getHeight()*1/100); 
	     missile11_y = (int)missile11.getY();
	     }
	     if(missile12_lance){
	    	 if(missile12.getX()<personnage_gauche.getX()+50 && missile12.getX()>personnage_gauche.getX()-50)
				{
					if(missile12.getY()>getHeight()-70 && missile12.getY()<getHeight())
					{
						gameover=true;
					}
				}
	    	 if(missile12.getY()>getHeight()){
				 missile12.setY(-getHeight()*96/100);
				 missile12_y = (int)missile12.getY();
				 missile12.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile12.setY(missile12_y+getHeight()*1/100); 
	     missile12_y = (int)missile12.getY();
	     }
	     if(missile13_lance){
	    	 if(missile13.getX()<personnage_gauche.getX()+50 && missile13.getX()>personnage_gauche.getX()-50)
				{
					if(missile13.getY()>getHeight()-70 && missile13.getY()<getHeight())
					{
						gameover=true;
					}
				}
	    	 if(missile13.getY()>getHeight()){
				 missile13.setY(-getHeight()*96/100);
				 missile13_y = (int)missile13.getY();
				 missile13.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile13.setY(missile13_y+getHeight()*1/100); 
	     missile13_y = (int)missile13.getY();
	     }
	     if(missile14_lance){
	    	 if(missile14.getX()<personnage_gauche.getX()+50 && missile14.getX()>personnage_gauche.getX()-50)
				{
					if(missile14.getY()>getHeight()-70 && missile14.getY()<getHeight())
					{
						gameover=true;
					}
				}
	    	 if(missile14.getY()>getHeight()){
				 missile14.setY(-getHeight()*96/100);
				 missile14_y = (int)missile14.getY();
				 missile14.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile14.setY(missile14_y+getHeight()*1/100); 
	     missile14_y = (int)missile14.getY();
	     }
	     if(missile15_lance){
	    	 if(missile15.getX()<personnage_gauche.getX()+50 && missile15.getX()>personnage_gauche.getX()-50)
				{
					if(missile15.getY()>getHeight()-70 && missile15.getY()<getHeight())
					{
						gameover=true;
					}
				}
	    	 if(missile15.getY()>getHeight()){
				 missile15.setY(-getHeight()*96/100);
				 missile15_y = (int)missile15.getY();
				 missile15.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile15.setY(missile15_y+getHeight()*1/100); 
	     missile15_y = (int)missile15.getY();
	     }
	     if(missile16_lance){
	    	 if(missile16.getX()<personnage_gauche.getX()+50 && missile16.getX()>personnage_gauche.getX()-50)
				{
					if(missile16.getY()>getHeight()-70 && missile16.getY()<getHeight())
					{
						gameover=true;
					}
				}
	    	 if(missile16.getY()>getHeight()){
				 missile16.setY(-getHeight()*96/100);
				 missile16_y = (int)missile16.getY();
				 missile16.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile16.setY(missile16_y+getHeight()*1/100); 
	     missile16_y = (int)missile16.getY();
	     }
	     if(missile17_lance){
	    	 if(missile17.getX()<personnage_gauche.getX()+50 && missile17.getX()>personnage_gauche.getX()-50)
				{
					if(missile17.getY()>getHeight()-70 && missile17.getY()<getHeight())
					{
						gameover=true;
					}
				}
	    	 if(missile17.getY()>getHeight()){
				 missile17.setY(-getHeight()*96/100);
				 missile17_y = (int)missile17.getY();
				 missile17.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile17.setY(missile17_y+getHeight()*1/100); 
	     missile17_y = (int)missile17.getY();
	     }
	     if(missile18_lance){
	    	 if(missile18.getX()<personnage_gauche.getX()+50 && missile18.getX()>personnage_gauche.getX()-50)
				{
					if(missile18.getY()>getHeight()-70 && missile18.getY()<getHeight())
					{
						gameover=true;
					}
				}
	    	 if(missile18.getY()>getHeight()){
				 missile18.setY(-getHeight()*96/100);
				 missile18_y = (int)missile18.getY();
				 missile18.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile18.setY(missile18_y+getHeight()*1/100); 
	     missile18_y = (int)missile18.getY();
	     }
	     if(missile19_lance){
	    	 if(missile19.getX()<personnage_gauche.getX()+50 && missile19.getX()>personnage_gauche.getX()-50)
				{
					if(missile19.getY()>getHeight()-70 && missile19.getY()<getHeight())
					{
						gameover=true;
					}
				}
	    	 if(missile19.getY()>getHeight()){
				 missile19.setY(-getHeight()*96/100);
				 missile19_y = (int)missile19.getY();
				 missile19.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile19.setY(missile19_y+getHeight()*1/100); 
	     missile19_y = (int)missile19.getY();
	     }
	     if(missile20_lance){
	    	 if(missile20.getX()<personnage_gauche.getX()+50 && missile20.getX()>personnage_gauche.getX()-50)
				{
					if(missile20.getY()>getHeight()-70 && missile20.getY()<getHeight())
					{
						gameover=true;
					}
				}
	    	 if(missile20.getY()>getHeight()){
				 missile20.setY(-getHeight()*96/100);
				 missile20_y = (int)missile20.getY();
				 missile20.setX((int)(-moitie_largeur+(getWidth()*Math.random())));
				 scores+=50*multiplicateur_score;
				 score.setText(ScoreToString(scores));
			 }
	     missile20.setY(missile20_y+getHeight()*1/100); 
	     missile20_y = (int)missile20.getY();
	     }
	     // Message du gameover
	     if(gameover)
	     {
	    	 SharedPreferences prefs = this.getSharedPreferences(SCORE_SAVED, Context.MODE_PRIVATE);
				Editor editor = prefs.edit();
				int highScore = prefs.getInt("saved", 0);
		    	if(scores > highScore ){
		    	    editor.putInt("saved", scores);
		    	    editor.commit();
		    	}
	    	 new AlertDialog.Builder(NewgameActivity.this)
			    .setTitle("GAME OVER")
			    .setMessage("SCORE : "+ScoreToString(scores))
			    .setPositiveButton("OK",new DialogInterface.OnClickListener() {
			        public void onClick(DialogInterface dialog, int which) {
			            finish();
			        }
			    })
			    .show();
	     }
	 }

		// Methode gerant le lancement des missiles "chacun leur tour"
		public void lancementMissile()
		 {
			if(missile1_lance == false)
		     {
		      missile1_lance = true;
		      missiles_lances++;
		     }
			try 
            {
				Thread.sleep(700);
            }
			catch(InterruptedException e)
			{
                e.printStackTrace();
			}
		     if(missile2_lance == false)
		     {
		      missile2_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		     if(missile3_lance == false)
		     {
		      missile3_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		     if(missile4_lance == false)
		     {
		      missile4_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		     if(missile5_lance == false)
		     {
		      missile5_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		     if(missile6_lance == false)
		     {
		      missile6_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		     if(missile7_lance == false)
		     {
		      missile7_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		     if(missile8_lance == false)
		     {
		      missile8_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		     if(missile9_lance == false)
		     {
		      missile9_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		     if(missile10_lance == false)
		     {
		      missile10_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		     if(missile11_lance == false)
		     {
		      missile11_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		     if(missile12_lance == false)
		     {
		      missile12_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		     if(missile13_lance == false)
		     {
		      missile13_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		     if(missile14_lance == false)
		     {
		      missile14_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		     if(missile15_lance == false)
		     {
		      missile15_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		     if(missile16_lance == false)
		     {
		      missile16_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		     if(missile17_lance == false)
		     {
		      missile17_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		     if(missile18_lance == false)
		     {
		      missile18_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		     if(missile19_lance == false)
		     {
		      missile19_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		     if(missile20_lance == false)
		     {
		      missile20_lance = true;
		      missiles_lances++;
		     }
		     try 
	            {
					Thread.sleep(700);
	            }
				catch(InterruptedException e)
				{
	                e.printStackTrace();
				}
		 }
	
	// Methode permettant de gerer l'image de la course vers la droite
	public void courseDroite() {
		asyncCourseDroite = new AsyncTask<Void, Void, Void>() {

	            
	            protected Void doInBackground(Void... params) {
	                if (droiteDown) {
	                    while (droiteDown) {
	                        try {
	                            Thread.sleep(27,5);
	                            runOnUiThread(new Runnable() {
	                                public void run() {
	                                    try {
	                                        changeImageDroite();
	                                    } catch (InterruptedException e) {
	                                        e.printStackTrace();
	                                    }
	                                }
	                            });

	                        } catch (InterruptedException e) {
	                            e.printStackTrace();
	                        }
	                    }
	                }
	                return null;
	            }
 
	        }.execute();
	    }
	 
	// Changement des images du personnage afin que la course vers la droite de celui-ci soit visible
	 public void changeImageDroite() throws InterruptedException {
		 if(personnage_droit.getX()<moitie_largeur-moitie_largeur*4/100)
         {
	        if(personnage_droite_1.getVisibility() == View.VISIBLE)
	        {
	        	personnage_droit.setVisibility(View.INVISIBLE);
	         personnage_droite_1.setVisibility(View.INVISIBLE);
	         personnage_droite_3.setVisibility(View.INVISIBLE);
	         personnage_droite_4.setVisibility(View.INVISIBLE);
	         personnage_droite_5.setVisibility(View.INVISIBLE);
	         personnage_droite_6.setVisibility(View.INVISIBLE);
	        	 personnage_gauche.setX(x+getWidth()*1/100);
		         personnage_droit.setX(x+getWidth()*1/100);
		         personnage_gauche_2.setX(x+getWidth()*1/100);
		         personnage_droite_2.setX(x+getWidth()*1/100);
		         x=(int)personnage_droite_2.getX();
	         personnage_droite_2.setVisibility(View.VISIBLE);
	        }
	        else if(personnage_droite_2.getVisibility() == View.VISIBLE)
	        {
	        	personnage_droit.setVisibility(View.INVISIBLE);
	        	personnage_droite_1.setVisibility(View.INVISIBLE);
	        	personnage_droite_2.setVisibility(View.INVISIBLE);
	        	personnage_droite_4.setVisibility(View.INVISIBLE);
	        	personnage_droite_5.setVisibility(View.INVISIBLE);
	        	personnage_droite_6.setVisibility(View.INVISIBLE);
	        		personnage_gauche.setX(x+getWidth()*1/100);
	   	         personnage_droit.setX(x+getWidth()*1/100);
	   	         personnage_gauche_3.setX(x+getWidth()*1/100);
	   	         personnage_droite_3.setX(x+getWidth()*1/100);
	   	         x=(int)personnage_droite_3.getX();
	         personnage_droite_3.setVisibility(View.VISIBLE);
	        }
	        else if(personnage_droite_3.getVisibility() == View.VISIBLE)
	        {
	        	personnage_droit.setVisibility(View.INVISIBLE);
	        	personnage_droite_1.setVisibility(View.INVISIBLE);
	        	personnage_droite_2.setVisibility(View.INVISIBLE);
	        	personnage_droite_3.setVisibility(View.INVISIBLE);
	        	personnage_droite_5.setVisibility(View.INVISIBLE);
	        	personnage_droite_6.setVisibility(View.INVISIBLE);
	        		personnage_gauche.setX(x+getWidth()*1/100);
	   	         personnage_droit.setX(x+getWidth()*1/100);
	   	         personnage_gauche_4.setX(x+getWidth()*1/100);
	   	         personnage_droite_4.setX(x+getWidth()*1/100);
	   	         x=(int)personnage_droite_4.getX();
	         personnage_droite_4.setVisibility(View.VISIBLE);
	        }
	        else if(personnage_droite_4.getVisibility() == View.VISIBLE)
	        {
	        	personnage_droit.setVisibility(View.INVISIBLE);
	        	personnage_droite_1.setVisibility(View.INVISIBLE);
	        	personnage_droite_2.setVisibility(View.INVISIBLE);
	        	personnage_droite_3.setVisibility(View.INVISIBLE);
	        	personnage_droite_4.setVisibility(View.INVISIBLE);
	        	personnage_droite_6.setVisibility(View.INVISIBLE);
	        		personnage_gauche.setX(x+getWidth()*1/100);
	   	         personnage_droit.setX(x+getWidth()*1/100);
	   	         personnage_gauche_5.setX(x+getWidth()*1/100);
	   	         personnage_droite_5.setX(x+getWidth()*1/100);
	   	         x=(int)personnage_droite_5.getX();
	         personnage_droite_5.setVisibility(View.VISIBLE);
	        }
	        else if(personnage_droite_5.getVisibility() == View.VISIBLE)
	        {
	        	personnage_droit.setVisibility(View.INVISIBLE);
	        	personnage_droite_1.setVisibility(View.INVISIBLE);
	        	personnage_droite_2.setVisibility(View.INVISIBLE);
	        	personnage_droite_3.setVisibility(View.INVISIBLE);
	        	personnage_droite_4.setVisibility(View.INVISIBLE);
	        	personnage_droite_5.setVisibility(View.INVISIBLE);
	        		personnage_gauche.setX(x+getWidth()*1/100);
	   	         personnage_droit.setX(x+getWidth()*1/100);
	   	         personnage_gauche_6.setX(x+getWidth()*1/100);
	   	         personnage_droite_6.setX(x+getWidth()*1/100);
	   	         x=(int)personnage_droite_6.getX();
	         personnage_droite_6.setVisibility(View.VISIBLE);
	        }
	        else if(personnage_droite_6.getVisibility() == View.VISIBLE)
	        {
	        	personnage_droit.setVisibility(View.INVISIBLE);
	        	personnage_droite_2.setVisibility(View.INVISIBLE);
	        	personnage_droite_3.setVisibility(View.INVISIBLE);
	        	personnage_droite_4.setVisibility(View.INVISIBLE);
	        	personnage_droite_5.setVisibility(View.INVISIBLE);
	        	personnage_droite_6.setVisibility(View.INVISIBLE);
	        		personnage_gauche.setX(x+getWidth()*1/100);
	   	         personnage_droit.setX(x+getWidth()*1/100);
	   	         personnage_gauche_1.setX(x+getWidth()*1/100);
	   	         personnage_droite_1.setX(x+getWidth()*1/100);
	   	         x=(int)personnage_droite_1.getX();
	         personnage_droite_1.setVisibility(View.VISIBLE);
	        }
         }
		 else
		 {
			personnage_droite_1.setVisibility(View.INVISIBLE);
	        personnage_droite_2.setVisibility(View.INVISIBLE);
	        personnage_droite_3.setVisibility(View.INVISIBLE);
	        personnage_droite_4.setVisibility(View.INVISIBLE);
	        personnage_droite_5.setVisibility(View.INVISIBLE);
	        personnage_droite_6.setVisibility(View.INVISIBLE);
	        personnage_droit.setVisibility(View.VISIBLE);
		 }
	 
	    }
	
	// Methode permettant de gerer l'image de la course vers la gauche
	public void courseGauche()
	{
	        asyncCourseGauche = new AsyncTask<Void, Void, Void>() {
	            protected Void doInBackground(Void... params) {
	                if (gaucheDown) {
	                    while (gaucheDown) {
	                        try {
	                            Thread.sleep(27,5);
	                            runOnUiThread(new Runnable() {

	                                
	                                public void run() {
	                                    try {
	                                        changeImageGauche();

	                                    } catch (InterruptedException e) {
	                                        e.printStackTrace();
	                                    }

	                                }
	                            });

	                        } catch (InterruptedException e) {
	                            e.printStackTrace();
	                        }
	                    }
	                }
	                return null;
	            }

	        }.execute();
	    }
	 
	// Changement des images du personnage afin que la course vers la gauche de celui-ci soit visible
	 public void changeImageGauche() throws InterruptedException {
		 if(personnage_gauche.getX()>-moitie_largeur+moitie_largeur*4/100)
         {
	        if(personnage_gauche_1.getVisibility() == View.VISIBLE)
	        {
	         personnage_gauche_1.setVisibility(View.INVISIBLE);
	         personnage_gauche_3.setVisibility(View.INVISIBLE);
	         personnage_gauche_4.setVisibility(View.INVISIBLE);
	         personnage_gauche_5.setVisibility(View.INVISIBLE);
	         personnage_gauche_6.setVisibility(View.INVISIBLE);
	         personnage_gauche.setX(x-getWidth()*1/100);
	         personnage_droit.setX(x-getWidth()*1/100);
	         personnage_gauche_2.setX(x-getWidth()*1/100);
	         personnage_droite_2.setX(x-getWidth()*1/100);
	         x=(int)personnage_gauche_2.getX();
	         personnage_gauche_2.setVisibility(View.VISIBLE);
	        }
	        else if(personnage_gauche_2.getVisibility() == View.VISIBLE)
	        {
	        	personnage_gauche_1.setVisibility(View.INVISIBLE);
		         personnage_gauche_2.setVisibility(View.INVISIBLE);
		         personnage_gauche_4.setVisibility(View.INVISIBLE);
		         personnage_gauche_5.setVisibility(View.INVISIBLE);
		         personnage_gauche_6.setVisibility(View.INVISIBLE);
	         personnage_gauche.setX(x-getWidth()*1/100);
	         personnage_droit.setX(x-getWidth()*1/100);
	         personnage_gauche_3.setX(x-getWidth()*1/100);
	         personnage_droite_3.setX(x-getWidth()*1/100);
	         x=(int)personnage_gauche_3.getX();
	         personnage_gauche_3.setVisibility(View.VISIBLE);
	        }
	        else if(personnage_gauche_3.getVisibility() == View.VISIBLE)
	        {
	        	personnage_gauche_1.setVisibility(View.INVISIBLE);
		         personnage_gauche_2.setVisibility(View.INVISIBLE);
		         personnage_gauche_3.setVisibility(View.INVISIBLE);
		         personnage_gauche_5.setVisibility(View.INVISIBLE);
		         personnage_gauche_6.setVisibility(View.INVISIBLE);
	         personnage_gauche.setX(x-getWidth()*1/100);
	         personnage_droit.setX(x-getWidth()*1/100);
	         personnage_gauche_4.setX(x-getWidth()*1/100);
	         personnage_droite_4.setX(x-getWidth()*1/100);
	         x=(int)personnage_gauche_4.getX();
	         personnage_gauche_4.setVisibility(View.VISIBLE);
	        }
	        else if(personnage_gauche_4.getVisibility() == View.VISIBLE)
	        {
	        	personnage_gauche_1.setVisibility(View.INVISIBLE);
		         personnage_gauche_2.setVisibility(View.INVISIBLE);
		         personnage_gauche_3.setVisibility(View.INVISIBLE);
		         personnage_gauche_4.setVisibility(View.INVISIBLE);
		         personnage_gauche_6.setVisibility(View.INVISIBLE);
	         personnage_gauche.setX(x-getWidth()*1/100);
	         personnage_droit.setX(x-getWidth()*1/100);
	         personnage_gauche_5.setX(x-getWidth()*1/100);
	         personnage_droite_5.setX(x-getWidth()*1/100);
	         x=(int)personnage_gauche_5.getX();
	         personnage_gauche_5.setVisibility(View.VISIBLE);
	        }
	        else if(personnage_gauche_5.getVisibility() == View.VISIBLE)
	        {
	        	personnage_gauche_1.setVisibility(View.INVISIBLE);
	        	personnage_gauche_2.setVisibility(View.INVISIBLE);
		         personnage_gauche_3.setVisibility(View.INVISIBLE);
		         personnage_gauche_4.setVisibility(View.INVISIBLE);
		         personnage_gauche_5.setVisibility(View.INVISIBLE);
	         personnage_gauche.setX(x-getWidth()*1/100);
	         personnage_droit.setX(x-getWidth()*1/100);
	         personnage_gauche_6.setX(x-getWidth()*1/100);
	         personnage_droite_6.setX(x-getWidth()*1/100);
	         x=(int)personnage_gauche_6.getX();
	         personnage_gauche_6.setVisibility(View.VISIBLE);
	        }
	        else if(personnage_gauche_6.getVisibility() == View.VISIBLE)
	        {
	        	personnage_gauche_2.setVisibility(View.INVISIBLE);
		         personnage_gauche_3.setVisibility(View.INVISIBLE);
		         personnage_gauche_4.setVisibility(View.INVISIBLE);
		         personnage_gauche_5.setVisibility(View.INVISIBLE);
	         personnage_gauche_6.setVisibility(View.INVISIBLE);
	         personnage_gauche.setX(x-getWidth()*1/100);
	         personnage_droit.setX(x-getWidth()*1/100);
	         personnage_gauche_1.setX(x-getWidth()*1/100);
	         personnage_droite_1.setX(x-getWidth()*1/100);
	         x=(int)personnage_gauche_1.getX();
	         personnage_gauche_1.setVisibility(View.VISIBLE);
	        }
         }
		 else
		 {
			 personnage_gauche_1.setVisibility(View.INVISIBLE);
			 personnage_gauche_2.setVisibility(View.INVISIBLE);
			 personnage_gauche_3.setVisibility(View.INVISIBLE);
			 personnage_gauche_4.setVisibility(View.INVISIBLE);
			 personnage_gauche_5.setVisibility(View.INVISIBLE);
			 personnage_gauche_6.setVisibility(View.INVISIBLE);
			 personnage_gauche.setVisibility(View.VISIBLE);
		 }
	    }
	 
	 // Mise en place du OnTouchListener sur le bouton droit
	 class droiteListener implements OnTouchListener {
		 	
	        public droiteListener(){}
	        public boolean onTouch(View v, MotionEvent event) {
	        	if(!gameover){
	         personnage_gauche.setVisibility(View.INVISIBLE);
	         personnage_droit.setVisibility(View.INVISIBLE);
	         personnage_droite_1.setVisibility(View.VISIBLE);
	            switch (event.getAction()) {
	            case MotionEvent.ACTION_DOWN:
	            	personnage_droite_1.setVisibility(View.INVISIBLE);
	                droiteDown = true;
	                courseDroite();
	                break;
	            case MotionEvent.ACTION_UP:
	                droiteDown = false;
	                personnage_droite_1.setVisibility(View.INVISIBLE);
	                personnage_droite_2.setVisibility(View.INVISIBLE);
	                personnage_droite_3.setVisibility(View.INVISIBLE);
	                personnage_droite_4.setVisibility(View.INVISIBLE);
	                personnage_droite_5.setVisibility(View.INVISIBLE);
	                personnage_droite_6.setVisibility(View.INVISIBLE);
	                personnage_droit.setVisibility(View.VISIBLE);
	                break;
	            }
	            return true;
	        	}
	        	return false;
	        }
	    }
	 
	// Mise en place du OnTouchListener sur le bouton gauche
	class gaucheListener implements OnTouchListener {
		
	        public gaucheListener(){}
	        public boolean onTouch(View v, MotionEvent event) {
	        	if(!gameover){
	         personnage_droit.setVisibility(View.INVISIBLE);
	         personnage_gauche.setVisibility(View.INVISIBLE);
	         personnage_gauche_1.setVisibility(View.VISIBLE);
	            switch (event.getAction()) {
	            case MotionEvent.ACTION_DOWN:
	            	personnage_gauche_1.setVisibility(View.INVISIBLE);
	                gaucheDown = true;
	                courseGauche();
	                break;
	            case MotionEvent.ACTION_UP:
	                gaucheDown = false;
	                personnage_gauche_1.setVisibility(View.INVISIBLE);
	                personnage_gauche_2.setVisibility(View.INVISIBLE);
	                personnage_gauche_3.setVisibility(View.INVISIBLE);
	                personnage_gauche_4.setVisibility(View.INVISIBLE);
	                personnage_gauche_5.setVisibility(View.INVISIBLE);
	                personnage_gauche_6.setVisibility(View.INVISIBLE);
	                personnage_gauche.setVisibility(View.VISIBLE);
	                break;
	            }
	            return true;
	        	}
	        	return false;
	        }
	    }
	
	// Transformation du score (int) en score (String)
	public String ScoreToString(int scores)
	 {
	  String string_score;
	  string_score = String.valueOf(scores);
	  return string_score;
	 }
	
}