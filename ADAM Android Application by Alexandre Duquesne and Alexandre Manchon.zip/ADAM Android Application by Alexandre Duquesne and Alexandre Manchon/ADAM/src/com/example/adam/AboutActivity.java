/*
 * @file   AboutActivity.java
 * @author Alexandre Duquesne and Alexandre Manchon
 * @date   31/01/2015
 * @brief  This is an android application/game named ADAM develloped for Universit� du Havre project
 * All rights reserved
 */

package com.example.adam;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class AboutActivity extends Activity {
	
	// Bouton retour vers le menu
	private Button bouton_back;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_about);
		
		bouton_back = (Button)findViewById(R.id.bouton_back_id);
		
		bouton_back.setOnClickListener(new OnClickListener()
		{
			public void onClick(View view)
			{
				finish(); // termine l'activite
			}
		});
	}
}
