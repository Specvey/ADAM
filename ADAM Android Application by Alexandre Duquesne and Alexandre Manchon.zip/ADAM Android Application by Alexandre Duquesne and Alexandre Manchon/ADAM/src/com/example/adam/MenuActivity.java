/*
 * @file   MenuActivity.java
 * @author Alexandre Duquesne and Alexandre Manchon
 * @date   31/01/2015
 * @brief  This is an android application/game named ADAM develloped for Universit� du Havre project
 * All rights reserved
 */

package com.example.adam;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.view.View.OnClickListener;

public class MenuActivity extends Activity
{
	// Bouton d'acces a newgame
	private Button bouton_newgame;
	// Bouton d'acces a about
	private Button bouton_about;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		setContentView(R.layout.activity_menu);
		super.onCreate(savedInstanceState);
		
		// Fais correspondre les boutons aux Button d'activity_menu.xml
		bouton_newgame = (Button)findViewById(R.id.bouton_newgame_id);
		bouton_about = (Button)findViewById(R.id.bouton_about_id);
		
		// Clic de newgame lancant NewgameActivity
		bouton_newgame.setOnClickListener(new OnClickListener()
		{
			public void onClick(View view)
			{
				Intent intent=new Intent(MenuActivity.this,NewgameActivity.class);
				startActivity(intent);
			}
		});
		
		// Clic d'about lancant AboutActivity
		bouton_about.setOnClickListener(new OnClickListener()
		{
			public void onClick(View view)
			{
				Intent intent=new Intent(MenuActivity.this,AboutActivity.class);
				startActivity(intent);
			}
		});
	}
}